# flake8: noqa
from .setup_loc import lang_init
