# from tkinter import ttk

btn_default_style = {
    'size': 5,
    'static_colour': (149, 213, 255),
    'static_t_colour': (0, 0, 0),
    'transformation_colour': (74, 184, 255),
    'transformation_t_colour': (0, 0, 0),
    'background': None
    # 'background': ttk.Style().lookup('TFrame', 'background')
}

btn_small_style = {
    'size': 3,
    'static_colour': (149, 213, 255),
    'static_t_colour': (0, 0, 0),
    'transformation_colour': (74, 184, 255),
    'transformation_t_colour': (0, 0, 0),
    'background': None
    # 'background': ttk.Style().lookup('TFrame', 'background')
}
